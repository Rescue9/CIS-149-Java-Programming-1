//package Ch8.Lab3;

public interface MessageEncoder {

	public String encode(String ciptherText);
}
