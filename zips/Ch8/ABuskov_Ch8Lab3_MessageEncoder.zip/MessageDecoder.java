//package Ch8.Lab3;

public interface MessageDecoder {

	public String decode(String plainText);
}
