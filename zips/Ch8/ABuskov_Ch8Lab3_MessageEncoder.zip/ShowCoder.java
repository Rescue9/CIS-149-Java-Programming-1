//package Ch8.Lab3;

public class ShowCoder {

	public static void main(String[] args){
		
		CoderFrame gui = new CoderFrame();
		gui.setVisible(true);
	}
}
